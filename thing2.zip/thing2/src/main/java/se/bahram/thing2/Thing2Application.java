package se.bahram.thing2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Thing2Application {

	public static void main(String[] args) {
		SpringApplication.run(Thing2Application.class, args);
	}

}
