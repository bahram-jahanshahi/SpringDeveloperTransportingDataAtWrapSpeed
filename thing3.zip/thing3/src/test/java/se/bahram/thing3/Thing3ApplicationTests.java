package se.bahram.thing3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Thing3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
